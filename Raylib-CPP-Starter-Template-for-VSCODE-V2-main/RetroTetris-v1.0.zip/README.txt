===============================
   RETRO TETRIS GAME
===============================

HOW TO PLAY:
1. Double-click RetroTetris.exe
2. Select difficulty level (1-12)
3. Use arrow keys to move blocks
4. Press SPACE to rotate
5. Try to get a high score!

CONTROLS:
- Arrow Left/Right: Move block
- Arrow Down: Soft drop
- SPACE: Rotate block
- CTRL/H: View high scores (from menu)
- ESC: Quit game

FEATURES:
- 12 difficulty levels
- Top 10 high scores with names
- Sound effects
- Smooth gameplay

Enjoy the game!
